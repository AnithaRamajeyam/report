package com.cts.eauction.beans;

public class UserDetails {
	String userId;
	String firstName;
	String lastName;
	String password;
	String reEnterPassword;
	String buildingNumberAndStreet;
	String city;
	String state;
	int pin;
	String  phone;
	String email;
	int paypalAccount;
	
	//Default Constructor
	public UserDetails()
	{
		
	}

	//Parameterized Constructor
	public UserDetails(String userId, String firstName, String lastName,
			String password, String reEnterPassword,
			String buildingNumberAndStreet, String city, String state,
			int pin, String  phone, String email, int paypalAccount) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.reEnterPassword = reEnterPassword;
		this.buildingNumberAndStreet = buildingNumberAndStreet;
		this.city = city;
		this.state = state;
		this.pin = pin;
		this.phone = phone;
		this.email = email;
		this.paypalAccount = paypalAccount;
	}
	public UserDetails(String userId, String firstName, String city,  String  phone, String email) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.city = city;
		this.phone = phone;
		this.email = email;
	}
	
	//Generate getters and setters
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getReEnterPassword() {
		return reEnterPassword;
	}

	public void setReEnterPassword(String reEnterPassword) {
		this.reEnterPassword = reEnterPassword;
	}

	public String getBuildingNumberAndStreet() {
		return buildingNumberAndStreet;
	}

	public void setBuildingNumberAndStreet(String buildingNumberAndStreet) {
		this.buildingNumberAndStreet = buildingNumberAndStreet;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String  getPhone() {
		return phone;
	}

	public void setPhone(String  phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPaypalAccount() {
		return paypalAccount;
	}

	public void setPaypalAccount(int paypalAccount) {
		this.paypalAccount = paypalAccount;
	}


}
