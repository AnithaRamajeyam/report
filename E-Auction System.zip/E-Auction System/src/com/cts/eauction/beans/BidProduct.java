package com.cts.eauction.beans;

public class BidProduct {

	int bidPrice;
	String bidId;
	String date;
	String productId;
	public BidProduct( String bidId,int bidPrice, String date, String productId) {
		super();
		this.bidPrice = bidPrice;
		this.bidId = bidId;
		this.date = date;
		this.productId = productId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public BidProduct() {
		
	}
	public int getBidPrice() {
		return bidPrice;
	}
	public void setBidPrice(int bidPrice) {
		this.bidPrice = bidPrice;
	}
	public String getBidId() {
		return bidId;
	}
	public void setBidId(String bidId) {
		this.bidId = bidId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

}
