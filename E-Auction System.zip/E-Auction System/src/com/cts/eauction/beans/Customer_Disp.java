package com.cts.eauction.beans;

public class Customer_Disp {
	
	String Product_name;
    String Desc;
    
    
    
    public Customer_Disp(String product_name, String desc) {
           super();
           Product_name = product_name;
           Desc = desc;
    }
    public Customer_Disp() {
           
    }
    public String getProduct_name() {
           return Product_name;
    }
    public void setProduct_name(String product_name) {
           Product_name = product_name;
    }
    public String getDesc() {
           return Desc;
    }
    public void setDesc(String desc) {
           Desc = desc;
    }
    


}
