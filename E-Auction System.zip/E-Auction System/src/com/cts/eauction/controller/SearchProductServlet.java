package com.cts.eauction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.eauction.beans.SearchProduct;
import com.cts.eauction.service.SearchProductService;
import com.cts.eauction.service.SearchProductServiceImpl;

@WebServlet("/SearchController")
public class SearchProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	SearchProductService service=new SearchProductServiceImpl();
	List<SearchProduct> search=new ArrayList<SearchProduct>();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		SearchProduct sp=new SearchProduct(request.getParameter("product"));
		search=service.getProductInfo(sp);
		service.updateSold(sp);
		HttpSession ss=request.getSession();
		request.setAttribute("seapro", search);
		RequestDispatcher rd=request.getRequestDispatcher("search.jsp");
		rd.forward(request, response);
		pw.close();	
	}


}
