package com.cts.eauction.controller;

import java.io.IOException;
//import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.beans.Customer_Disp;

import com.cts.eauction.service.MySalesService;
import com.cts.eauction.service.MySalesServiceImpl;



@WebServlet("/MySalesServlet")
public class MySalesServlet extends HttpServlet {
	
   
    private static final long serialVersionUID = 1L;
MySalesService serv = new MySalesServiceImpl();
Customer c = new Customer();
List<Customer_Disp> cd = new ArrayList<Customer_Disp>();
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
        response.setContentType("text/html");
        //PrintWriter pw = response.getWriter();
        HttpSession ss = request.getSession(); 
		String user_id = (String) ss.getAttribute("UserId");
		System.out.println(user_id);
		c.setUserId(user_id);
        cd = serv.Disp(c);
        request.setAttribute("DispObj", cd);

        RequestDispatcher rd = request.getRequestDispatcher("sales.jsp");
        rd.forward(request, response);

	}

}
