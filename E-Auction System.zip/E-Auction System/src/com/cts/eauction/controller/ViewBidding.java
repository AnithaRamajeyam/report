package com.cts.eauction.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.eauction.beans.BidProduct;
import com.cts.eauction.service.ViewBiddingService;
import com.cts.eauction.service.ViewBiddingServiceImpl;

@WebServlet("/ViewBidding")
public class ViewBidding extends HttpServlet {
	private static final long serialVersionUID = 1L;
		ViewBiddingService serv = new ViewBiddingServiceImpl();
		BidProduct bp = new BidProduct();
		List<BidProduct> bps=new ArrayList<BidProduct>();
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			   response.setContentType("text/html");
		      
				String cate=request.getParameter("product");
				BidProduct bp = new BidProduct(cate);
				bps = serv.ViewBidding(bp);
		        request.setAttribute("View",bps);

		         request.getRequestDispatcher("ViewBidding.jsp").include(request, response);
		         
			
		}
}
