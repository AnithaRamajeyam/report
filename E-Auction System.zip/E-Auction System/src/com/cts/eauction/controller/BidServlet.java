package com.cts.eauction.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.eauction.beans.BidProduct;
import com.cts.eauction.service.BidService;
import com.cts.eauction.service.BidServiceImpl;



@WebServlet("/BidServlet")
	public class BidServlet extends HttpServlet {
		private static final long serialVersionUID = 1L;
	   
		BidService service=new BidServiceImpl();
		List<BidProduct> bps=new ArrayList<BidProduct>();
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NumberFormatException {
			response.setContentType("text/html");
			int bidPrice=Integer.parseInt(request.getParameter("bidPrice")) ;
			HttpSession ss = request.getSession(); 
			String bidId = (String) ss.getAttribute("UserId");
			//System.out.println(bidId);
			String pid = (String) ss.getAttribute("pid");
			String date=request.getParameter("date") ;
			//System.out.println("adga"+date);
			BidProduct bp= new BidProduct();
			bp.setBidPrice(bidPrice); 
			bp.setBidId(bidId);
			bp.setProductId(pid);
			bp.setDate(date);
			
			if(service.Update(bp))
			{
				bps=service.getBidDetails(bp);
				request.setAttribute("bidtable",bp);
				RequestDispatcher r1= request.getRequestDispatcher("display.jsp");
				r1.forward(request, response);
			}
			else
			{
				request.setAttribute("errormsg","Bidding price is lower compare to theprice before entered");
				RequestDispatcher r1= request.getRequestDispatcher("display.jsp");
				r1.forward(request, response);
			}
			
		}
}
