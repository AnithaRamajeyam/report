package com.cts.eauction.controller;

import java.io.IOException;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.service.CustomerService;
import com.cts.eauction.service.CustomerServiceImpl;



@WebServlet("/PutSales")
public class PutSalesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	CustomerService serv = new CustomerServiceImpl();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("TEXT/HTML");
		PrintWriter  pw = response.getWriter();
		String uid = request.getParameter("User_id");
		String pid = request.getParameter("Product_id");
		String pdtname = request.getParameter("Product_name");
		String short_desc = request.getParameter("Short_desc");
		String det_desc = request.getParameter("Detailed_desc");
		String Category = request.getParameter("Category");
		int price = Integer.parseInt(request.getParameter("Starting_price"));
		String bid_date = request.getParameter("Bid_end_date");
		String status = "NOT SOLD";
		try
	    {
	      
	      SimpleDateFormat sdfSource = new SimpleDateFormat("mm/dd/yyyy");
	      
	     
	      Date date = sdfSource.parse(bid_date);
	      
	      SimpleDateFormat sdfDestination = new SimpleDateFormat("yyyy/mm/dd");
	      
	      
	      bid_date = sdfDestination.format(date);
	    
	      
	    }
	    catch(ParseException pe)
	    { 
	      System.out.println("Parse Exception : " + pe);
	    }
		
		Customer cus = new Customer(uid,pid,pdtname,short_desc,det_desc,Category,price,bid_date,status);
		
		Boolean r = serv.Insert(cus);
		RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
		
		if(r)
		{
			RequestDispatcher rd1 = request.getRequestDispatcher("Home.jsp");
			pw.println("<script type=\"text/javascript\">");
			pw.println("alert('Product Registered sucessfully');");
			pw.println("</script>");
			rd1.include(request, response);
		}
		else
			pw.println("error");
		
		
		
		
	}

}
