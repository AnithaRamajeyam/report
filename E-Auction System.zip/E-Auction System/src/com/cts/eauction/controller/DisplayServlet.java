package com.cts.eauction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.eauction.beans.Display;
import com.cts.eauction.service.DispalyServiceImpl;
import com.cts.eauction.service.DisplayService;




@WebServlet("/DisplayServlet")
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		DisplayService service=new DispalyServiceImpl();
		List<Display> disp=new ArrayList<Display>();
				
			response.setContentType("text/html");
			PrintWriter pw=response.getWriter();
			String pid =request.getParameter("pid");
			
			Display sp=new Display(pid);
			disp=service.getProductDetails(sp);
			request.setAttribute("display", disp);
			
			RequestDispatcher rd=request.getRequestDispatcher("display.jsp");
			rd.forward(request, response);
			pw.close();	
		}

}


