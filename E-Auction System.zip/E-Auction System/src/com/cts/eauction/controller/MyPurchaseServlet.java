package com.cts.eauction.controller;

import java.io.IOException;
//import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;

import com.cts.eauction.beans.Purchase;
import com.cts.eauction.service.MyPurchaseService;
import com.cts.eauction.service.MyPurchaseServiceImpl;


@WebServlet("/MyPurchaseServlet")
public class MyPurchaseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	MyPurchaseService pi=new MyPurchaseServiceImpl();
	Purchase p=new Purchase();
  
	//String user_id,Product_name,Description,Final_price;
    List<Purchase> pur_obj=new ArrayList<Purchase>();
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		//PrintWriter pw=response.getWriter();
	
		HttpSession ss = request.getSession(); 
		String user_id = (String) ss.getAttribute("UserId");
		System.out.println(user_id);
		p.setUser_id(user_id);
		pur_obj=pi.purchase(p);
		request.setAttribute("Dis_obj", pur_obj);
		
		RequestDispatcher rd=request.getRequestDispatcher("purchase.jsp");
		rd.forward(request, response);
	}
}
