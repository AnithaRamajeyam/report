package com.cts.eauction.dao;

import com.cts.eauction.beans.UserDetails;




public interface MyProfileDao {
	
	public UserDetails UpdateUserDetails(String user_id);
	

}
