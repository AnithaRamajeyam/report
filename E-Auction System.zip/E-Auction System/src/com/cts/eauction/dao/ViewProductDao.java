package com.cts.eauction.dao;

import java.util.List;

import com.cts.eauction.beans.Customer;


public interface ViewProductDao {
	public List<Customer> ViewProduct(Customer c);

}
