package com.cts.eauction.dao;

import java.util.List;

import com.cts.eauction.beans.UserDetails;

public interface ViewUserDao {
	public List<UserDetails> ViewUser(UserDetails user);
}
