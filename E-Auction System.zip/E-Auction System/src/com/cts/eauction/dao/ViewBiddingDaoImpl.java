package com.cts.eauction.dao;

public class ViewBiddingDaoImpl {

}
