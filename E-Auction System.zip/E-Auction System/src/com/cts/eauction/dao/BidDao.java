package com.cts.eauction.dao;

import java.util.List;

import com.cts.eauction.beans.BidProduct;



public interface BidDao {

	public boolean Update(BidProduct bp); 
	 List<BidProduct> getBidDetails(BidProduct bp);
}
