package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class CustomerDaoImpl implements CustomerDao {
	
	Connection con = null;
	PreparedStatement pst = null;
	
	@Override
	public void createTableSales() {
		try {
			
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("create table if not exists put_for_sales(user_id varchar(20),product_id varchar(20),product_name varchar(20),short_desc varchar(20),detailed_desc varchar(50),category varchar(50),price int(20),bid_end_date date,status varchar(20),last_bid_price int(20),remaining_days int(10));");
			pst.executeUpdate();
			System.out.println("table created");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	@Override
	public void createTableBidding() {
		
		try {
			
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("create table if not exists bidding(bid varchar(10),bidding_price int(50),rdate date,product_id varchar(11) references put_for_sales(product_id),category varchar(20))");
			pst.executeUpdate();
			System.out.println("table created");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void createTablePurchase() {
		
		try {
			
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("create table if not exists purchase(user_id varchar(20),product_id varchar(20),product_name varchar(20),short_desc varchar(20),detailed_desc varchar(50),category varchar(50),price int(20));");
			pst.executeUpdate();
			System.out.println("table created");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
	@Override
	public Boolean Insert(Customer c) {
		
		SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
		String date=sf.format(new Date());
		
		Boolean res = false;
		try {
			
			con = DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME,DbConstants.PWD);
			pst = con.prepareStatement("insert into put_for_sales values(?,?,?,?,?,?,?,?,?,?,?)");
			pst.setString(1, c.getUserId());
		//System.out.println(c.getUserId());
			pst.setString(2,c.getProductId());
		//System.out.println(c.getProductId());
			pst.setString(3, c.getPdtName());
		//System.out.println(c.getPdtName());
			pst.setString(4, c.getShortDesc());
		//System.out.println(c.getShortDesc());
			pst.setString(5, c.getDetDesc());
		//System.out.println( c.getDetDesc());	
			pst.setString(6, c.getCategory());
		//System.out.println( c.getCategory());	
			pst.setInt(7, c.getPrice());
		//System.out.println(  c.getPrice());	
			pst.setString(8, c.getBid_End_date());
		//System.out.println(c.getBid_End_date());
			pst.setString(9,c.getStatus());
		//System.out.println(c.getStatus());
			pst.setInt(10,c.getPrice());
			System.out.println(c.getBid_End_date());
			String date2 = c.getBid_End_date();
			DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
			LocalDate now = LocalDate.now(); 
			LocalDate  d2 = LocalDate.parse(date2, df);
			int days= (int) ChronoUnit.DAYS.between(now,d2);
			pst.setInt(11,days);
			int r = pst.executeUpdate();
			if(r > 0)
				res = true;
			else
				res = false;
			
			
			pst = con.prepareStatement("insert into bidding(bidding_price,product_id,category) values(?,?,?)");
			pst.setInt(1, c.getPrice());
			System.out.println(c.getPrice());
			pst.setString(2,c.getProductId());
			pst.setString(3, c.getCategory());
			pst.executeUpdate();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}	
}