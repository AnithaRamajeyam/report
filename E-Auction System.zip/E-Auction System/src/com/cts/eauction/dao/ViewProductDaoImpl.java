package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.beans.Display;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class ViewProductDaoImpl implements ViewProductDao {

	@Override
	public List<Customer> ViewProduct(Customer c) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		List<Customer> view=new ArrayList<Customer>();
		try {
			System.out.println("daoimpl");
			conn = DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME,DbConstants.PWD);
			pst = conn.prepareStatement("select * from put_for_sales where user_id=?");
			pst.setString(1,c.getUserId());
			System.out.println(c.getUserId());
			rs= pst.executeQuery();		
			while(rs.next())
			{
				System.out.println("inside");
				view.add(new Customer(rs.getString(1),rs.getString(3),rs.getString(6),rs.getInt(7),rs.getString(8)));
			}
			rs.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	return view;
	}
}
