package com.cts.eauction.dao;

import java.util.List;

import com.cts.eauction.beans.Purchase;

public interface MyPurchaseDao {

	public List<Purchase> purchase(Purchase p);
}
