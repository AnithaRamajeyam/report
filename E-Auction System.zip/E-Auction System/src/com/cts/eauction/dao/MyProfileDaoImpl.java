package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class MyProfileDaoImpl implements MyProfileDao {

	@Override
	public UserDetails UpdateUserDetails(String user_id) {
		
		Connection con=null;
		PreparedStatement pst=null;
		UserDetails user=null;
		
		try {
			//String user_id="user1";
			//String user_id=request.getAttribute("UserId");
			con=DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			pst=con.prepareStatement("select * from user_details where user_id=?");
			pst.setString(1,user_id);
			ResultSet rs=pst.executeQuery();
			rs.next();
			String userId=rs.getString("user_id");
		    String firstName=rs.getString("first_name");
		    String lastName=rs.getString("last_name");
		    String password=rs.getString("password");
		    String reEnterPassword=rs.getString("password");
		    String building =rs.getString("building_number_and_street");
		    String city=rs.getString("city");
		    String state=rs.getString("state");
		    int pin=Integer.parseInt(rs.getString("pin"));
		    String phone=rs.getString("phone");
		    String email=rs.getString("email");
		    int paypalAccount=Integer.parseInt(rs.getString("paypal_account"));
		
		    user=new UserDetails();
				 user.setUserId(userId);
			     user.setFirstName(firstName);
			     user.setLastName(lastName);
			     user.setPassword(password);
			     user.setReEnterPassword(reEnterPassword);
			     user.setBuildingNumberAndStreet(building);
			     user.setCity(city);
			     user.setState(state);
			     user.setPin(pin);
			     user.setPhone(phone);
			     user.setEmail(email);
			     user.setPaypalAccount(paypalAccount);
			     
				
			 con.close();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return user;
		
	}

}
