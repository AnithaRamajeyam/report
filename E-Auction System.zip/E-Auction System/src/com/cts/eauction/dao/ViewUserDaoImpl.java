package com.cts.eauction.dao;

public class ViewUserDaoImpl {

}
