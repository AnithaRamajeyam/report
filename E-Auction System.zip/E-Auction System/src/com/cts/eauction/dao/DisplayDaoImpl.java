package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.Display;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;



public class DisplayDaoImpl implements DisplayDao{

	@Override
	public List<Display> getProductDetails(Display sp) {
		
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs=null;
		List<Display> disp=new ArrayList<Display>();
		try {
			
			conn = DbUtil.getConnection(DbConstants.DRIVER, DbConstants.URL, DbConstants.UNAME,DbConstants.PWD);
			pst = conn.prepareStatement("select * from put_for_sales where Product_id=?");
			pst.setString(1, sp.getPid());
			//System.out.println(sp.getPid());
			rs= pst.executeQuery();
			
			while(rs.next())
			{
		
				disp.add(new Display(rs.getInt(7),rs.getString(3),rs.getString(5)));
			}
			rs.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	return disp;
  }
}
