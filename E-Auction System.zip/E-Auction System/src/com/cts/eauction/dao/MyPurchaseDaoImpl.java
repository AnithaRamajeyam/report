package com.cts.eauction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.Purchase;
import com.cts.eauction.util.DbConstants;
import com.cts.eauction.util.DbUtil;

public class MyPurchaseDaoImpl implements MyPurchaseDao {

	

	private static final String User_id = null;

	List<Purchase> pur=new ArrayList<Purchase>();
	@Override
	public List<Purchase> purchase(Purchase p) {
		// TODO Auto-generated method stub
	

		System.out.println("bhjhb");
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			System.out.println("bhjhb");
			System.out.println(p.getUser_id());
			con=DbUtil.getConnection(DbConstants.DRIVER , DbConstants.URL, DbConstants.UNAME, DbConstants.PWD);
			ps=con.prepareStatement("select * from bidding where bid=?");
			ps.setString(1,p.getUser_id());
			rs=ps.executeQuery();
			System.out.println("bhjhb");
			while(rs.next())
			{
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				pur.add(new Purchase(rs.getString(1),rs.getString(2),rs.getString(3)));
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
			
		}
		
		return pur;
	}
}
