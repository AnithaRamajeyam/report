package com.cts.eauction.dao;

public interface ViewBiddingDao {

}
