package com.cts.eauction.dao;

import java.util.List;

import com.cts.eauction.beans.Customer;
import com.cts.eauction.beans.Customer_Disp;
public interface MySalesDao {

	
    public List<Customer_Disp> SalesDisp(Customer c);
}
