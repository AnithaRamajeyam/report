package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.Display;



public interface DisplayService {

	public List<Display> getProductDetails(Display sp);
}
