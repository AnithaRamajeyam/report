package com.cts.eauction.service;

public interface ViewBiddingServiceImpl {

}
