package com.cts.eauction.service;

import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.BidProduct;
import com.cts.eauction.dao.ViewBiddingDao;
import com.cts.eauction.dao.ViewBiddingDaoImpl;


public class ViewBiddingServiceImpl implements ViewBiddingService {
	ViewBiddingDao dao = new ViewBiddingDaoImpl();
    List<BidProduct> cd = new ArrayList<BidProduct>();
	@Override
	public List<BidProduct> ViewBidding(BidProduct bp) {
			System.out.println("serimpl");
		cd = dao.ViewBidding(bp);
        return cd;
	}
}
