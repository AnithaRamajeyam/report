package com.cts.eauction.service;


public interface LoginService {
	public boolean loginservice(String user_id,String password);
}
