package com.cts.eauction.service;

import com.cts.eauction.beans.UserDetails;



public interface MyProfileService {
	public UserDetails UpdateUser(String user_id);

}
