package com.cts.eauction.service;

import com.cts.eauction.beans.UserDetails;
import com.cts.eauction.dao.UpdateUserDao;
import com.cts.eauction.dao.UpdateUserDaoImpl;

public class UpdateUserServiceImpl implements UpdateUserService {

	UpdateUserDao upddao=new UpdateUserDaoImpl();
	@Override
	public boolean updateService(UserDetails user) {
		
		boolean res=upddao.updateDao(user);
		return res;
	}
	

}
