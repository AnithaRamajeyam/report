package com.cts.eauction.service;

import java.util.ArrayList;
import java.util.List;

import com.cts.eauction.beans.Purchase;
import com.cts.eauction.dao.MyPurchaseDao;
import com.cts.eauction.dao.MyPurchaseDaoImpl;

public class MyPurchaseServiceImpl implements MyPurchaseService {

	MyPurchaseDao pi=new MyPurchaseDaoImpl();
	List<Purchase> pr=new ArrayList<Purchase>();
	@Override
	public List<Purchase> purchase(Purchase p) {
			pr=pi.purchase(p);
		
		return pr;
	}
}
