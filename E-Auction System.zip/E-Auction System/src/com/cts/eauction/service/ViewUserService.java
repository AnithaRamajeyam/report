package com.cts.eauction.service;

import java.util.List;

import com.cts.eauction.beans.UserDetails;

public interface ViewUserService {
	public List<UserDetails> ViewUser(UserDetails user);
}
